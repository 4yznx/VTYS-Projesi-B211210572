﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace Pgadmin4
{
    public partial class Form1 : Form
    {

        private string connectionString = "server=localhost ;port=5432; user id=postgres; password=Sakarya@54; database=kitapProjesi";
        private NpgsqlConnection connection;
        private NpgsqlDataAdapter adapter;
        private DataSet dataSet;
        private string currentTableName;


        public Form1()
        {
            InitializeComponent();
            connection = new NpgsqlConnection(connectionString);
            adapter = new NpgsqlDataAdapter();
            dataSet = new DataSet();
            button8.Click += button8_Click_1;
            button9.Click += button9_Click;
            button10.Click += button10_Click;
            button11.Click += button11_Click;
            button12.Click += button12_Click;
            button13.Click += button13_Click;
            button14.Click += button14_Click;
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoadData("SELECT * FROM yazar", "yazar");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            LoadData("SELECT * FROM kitap.kitap", "kitap");

        }

        private void button3_Click(object sender, EventArgs e)
        {
            LoadData("SELECT * FROM yayincilar", "yayincilar");
        }

        private void LoadData(string query, string tableName)
        {
            try
            {
                connection.Open();

                adapter.SelectCommand = new NpgsqlCommand(query, connection);

                dataSet.Clear();

                adapter.Fill(dataSet, tableName);

                dataGridView1.DataSource = dataSet.Tables[tableName];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            LoadData("SELECT * FROM kitap.manga", "manga");

        }

        private void button5_Click(object sender, EventArgs e)
        {
            LoadData("SELECT * FROM kitap.felsefe", "felsefe");

        }

        private void button4_Click(object sender, EventArgs e)
        {
            LoadData("SELECT * FROM kitap.macera", "macera");

        }

        private void button7_Click(object sender, EventArgs e)
        {
            LoadData("SELECT * FROM kitap.polisiye", "polisiye");

        }

        private void SaveChanges1()
        {
            try
            {
                connection.Open();

                NpgsqlCommandBuilder builder = new NpgsqlCommandBuilder(adapter);
                adapter.Update(dataSet, "yazar");

                MessageBox.Show("Changes saved successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving changes: " + ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }
        private void SaveChanges2()
        {
            try
            {
                connection.Open();

                NpgsqlCommandBuilder builder = new NpgsqlCommandBuilder(adapter);
                adapter.Update(dataSet, "kitap");

                MessageBox.Show("Changes saved successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving changes: " + ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }
        private void SaveChanges3()
        {
            try
            {
                connection.Open();

                NpgsqlCommandBuilder builder = new NpgsqlCommandBuilder(adapter);
                adapter.Update(dataSet, "yayincilar");

                MessageBox.Show("Changes saved successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving changes: " + ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }
        private void SaveChanges4()
        {
            try
            {
                connection.Open();

                NpgsqlCommandBuilder builder = new NpgsqlCommandBuilder(adapter);
                adapter.Update(dataSet, "manga");

                MessageBox.Show("Changes saved successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving changes: " + ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }
        private void SaveChanges5()
        {
            try
            {
                connection.Open();

                NpgsqlCommandBuilder builder = new NpgsqlCommandBuilder(adapter);
                adapter.Update(dataSet, "felsefe");

                MessageBox.Show("Changes saved successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving changes: " + ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }
        private void SaveChanges6()
        {
            try
            {
                connection.Open();

                NpgsqlCommandBuilder builder = new NpgsqlCommandBuilder(adapter);
                adapter.Update(dataSet, "macera");

                MessageBox.Show("Changes saved successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving changes: " + ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }
        private void SaveChanges7()
        {
            try
            {
                connection.Open();

                NpgsqlCommandBuilder builder = new NpgsqlCommandBuilder(adapter);
                adapter.Update(dataSet, "polisiye");

                MessageBox.Show("Changes saved successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving changes: " + ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            SaveChanges1();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            SaveChanges2();

        }

        private void button10_Click(object sender, EventArgs e)
        {
            SaveChanges3();

        }

        private void button11_Click(object sender, EventArgs e)
        {
            SaveChanges4();

        }

        private void button12_Click(object sender, EventArgs e)
        {
            SaveChanges5();

        }

        private void button13_Click(object sender, EventArgs e)
        {
            SaveChanges6();

        }

        private void button14_Click(object sender, EventArgs e)
        {
            SaveChanges7();

        }


    }

}

